/*jshint esversion: 6 */

function floorCall(floor, direction) {
	return {
		floor: floor,
		direction: direction
	};
}
